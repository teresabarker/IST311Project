/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package module4activity3;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author MacBookPro
 */
public class MainScreenTest {
    
    public MainScreenTest() {
    }

    /**
     * Test of getStudent method, of class MainScreen.
     */
    @Test
    public void testGetStudent() {
        System.out.println("getStudent");
        MainScreen instance = new MainScreen("James", "IST");
        String expResult = "James";
        String result = instance.getStudent();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

   

    /**
     * Test of getMajor method, of class MainScreen.
     */
    @Test
    public void testGetMajor() {
        System.out.println("getMajor");
        MainScreen instance = new MainScreen ("James", "IST");
        String expResult = "IST";
        String result = instance.getMajor();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

   
    
}
