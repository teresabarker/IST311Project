/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package module4activity3;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author MacBookPro
 */
public class CurrentStudyGroupTest {
    
    public CurrentStudyGroupTest() {
    }

    /**
     * Test of getGroupInfo method, of class CurrentStudyGroup.
     */
    @Test
    public void testGetGroupInfo() {
        System.out.println("getGroupInfo");
        CurrentStudyGroup instance = null;
        String expResult = "";
        String result = instance.getGroupInfo();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    

    /**
     * Test of getMyGroups method, of class CurrentStudyGroup.
     */
    @Test
    public void testGetMyGroups() {
        System.out.println("getMyGroups");
        CurrentStudyGroup instance = null;
        String expResult = "";
        String result = instance.getMyGroups();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
