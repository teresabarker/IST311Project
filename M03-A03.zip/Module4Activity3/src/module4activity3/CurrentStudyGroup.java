/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package module4activity3;

/**
 *
 * @author MacBookPro
 */
public class CurrentStudyGroup 
{
    private String groupInfo;
    private String myGroups;
    
    public CurrentStudyGroup(String grps, String mygrp)
    {
        myGroups = grps;
        groupInfo = mygrp;
    }
    
     public String getGroupInfo() 
    {
        return groupInfo;
    }

  
    public void setGroupInfo(String groupInfo) 
    {
        this.groupInfo = groupInfo;
    }
    
     public String getMyGroups() 
    {
        return myGroups;
    }

    
    public void setMyGroups(String myGroups) {
        this.myGroups = myGroups;
    }
}

