/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package module4activity3;

/**
 *
 * @author MacBookPro
 */
public class MainScreen 
{
    private String student;
    private String myMajor;
    
    public MainScreen (String name, String mjr)
    {
        student = name;
        myMajor =mjr;
    }
    
     public String getStudent() 
    {
        return student;
    }

  
    public void setStudent(String student) 
    {
        this.student = student;
    }
    
     public String getMajor() 
    {
        return myMajor;
    }

    
    public void setMajor(String mjr) {
        this.myMajor = mjr;
    }
}
