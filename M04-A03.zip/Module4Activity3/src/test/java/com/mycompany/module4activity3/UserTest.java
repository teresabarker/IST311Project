/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.module4activity3;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author angel
 */
public class UserTest {
    
    public UserTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }

    /**
     * Test of getUserFirstName method, of class User.
     */
    @Test
    public void testGetUserFirstName() {
        System.out.println("getUserFirstName");
        User instance = new User();
        String expResult = "";
        String result = instance.getUserFirstName();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setUserFirstName method, of class User.
     */
    @Test
    public void testSetUserFirstName() {
        System.out.println("setUserFirstName");
        String userFirstName = "";
        User instance = new User();
        instance.setUserFirstName(userFirstName);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getUserLastName method, of class User.
     */
    @Test
    public void testGetUserLastName() {
        System.out.println("getUserLastName");
        User instance = new User();
        String expResult = "";
        String result = instance.getUserLastName();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setUserLastName method, of class User.
     */
    @Test
    public void testSetUserLastName() {
        System.out.println("setUserLastName");
        String userLastName = "";
        User instance = new User();
        instance.setUserLastName(userLastName);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getUserEmail method, of class User.
     */
    @Test
    public void testGetUserEmail() {
        System.out.println("getUserEmail");
        User instance = new User();
        String expResult = "";
        String result = instance.getUserEmail();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setUserEmail method, of class User.
     */
    @Test
    public void testSetUserEmail() {
        System.out.println("setUserEmail");
        String userEmail = "";
        User instance = new User();
        instance.setUserEmail(userEmail);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getUserPassword method, of class User.
     */
    @Test
    public void testGetUserPassword() {
        System.out.println("getUserPassword");
        User instance = new User();
        String expResult = "";
        String result = instance.getUserPassword();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setUserPassword method, of class User.
     */
    @Test
    public void testSetUserPassword() {
        System.out.println("setUserPassword");
        String userPassword = "";
        User instance = new User();
        instance.setUserPassword(userPassword);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getFullName method, of class User.
     */
    @Test
    public void testGetFullName() {
        System.out.println("getFullName");
        User instance = new User();
        String expResult = " ";
        String result = instance.getFullName();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of isPassword method, of class User.
     */
    @Test
    public void testIsPassword() {
        System.out.println("isPassword");
        String password = "";
        User instance = new User();
        boolean expResult = true;
        boolean result = instance.isPassword(password);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of isEmail method, of class User.
     */
    @Test
    public void testIsEmail() {
        System.out.println("isEmail");
        String user = "";
        User instance = new User();
        boolean expResult = true;
        boolean result = instance.isEmail(user);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
}
