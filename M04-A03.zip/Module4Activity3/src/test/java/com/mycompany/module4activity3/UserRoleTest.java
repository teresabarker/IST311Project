/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.module4activity3;

import java.util.ArrayList;
import java.util.Calendar;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author angel
 */
public class UserRoleTest {
    
    public UserRoleTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }

    /**
     * Test of getUserClasses method, of class UserRole.
     */
    @Test
    public void testGetUserClasses() {
        System.out.println("getUserClasses");
        UserRole instance = new UserRole();
        ArrayList<String> expResult = null;
        ArrayList<String> result = instance.getUserClasses();
        //assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setUserClasses method, of class UserRole.
     */
    @Test
    public void testSetUserClasses() {
        System.out.println("setUserClasses");
        ArrayList<String> userClasses = null;
        UserRole instance = new UserRole();
        instance.setUserClasses(userClasses);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getUserSchedule method, of class UserRole.
     */
    @Test
    public void testGetUserSchedule() {
        System.out.println("getUserSchedule");
        UserRole instance = new UserRole();
        ArrayList<Calendar> expResult = null;
        ArrayList<Calendar> result = instance.getUserSchedule();
        //assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setUserSchedule method, of class UserRole.
     */
    @Test
    public void testSetUserSchedule() {
        System.out.println("setUserSchedule");
        ArrayList<Calendar> userSchedule = null;
        UserRole instance = new UserRole();
        instance.setUserSchedule(userSchedule);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getUserType method, of class UserRole.
     */
    @Test
    public void testGetUserType() {
        System.out.println("getUserType");
        UserRole instance = new UserRole();
        int expResult = 0;
        int result = instance.getUserType();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setUserType method, of class UserRole.
     */
    @Test
    public void testSetUserType() {
        System.out.println("setUserType");
        int userType = 0;
        UserRole instance = new UserRole();
        instance.setUserType(userType);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getUserDegrees method, of class UserRole.
     */
    @Test
    public void testGetUserDegrees() {
        System.out.println("getUserDegrees");
        UserRole instance = new UserRole();
        ArrayList<String> expResult = null;
        ArrayList<String> result = instance.getUserDegrees();
        //assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setUserDegrees method, of class UserRole.
     */
    @Test
    public void testSetUserDegrees() {
        System.out.println("setUserDegrees");
        ArrayList<String> userDegrees = null;
        UserRole instance = new UserRole();
        instance.setUserDegrees(userDegrees);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of isAvailable method, of class UserRole.
     */
    @Test
    public void testIsAvailable() {
        System.out.println("isAvailable");
        UserRole instance = new UserRole();
        boolean expResult = false;
        boolean result = instance.isAvailable();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of isInstructor method, of class UserRole.
     */
    @Test
    public void testIsInstructor() {
        System.out.println("isInstructor");
        UserRole instance = new UserRole();
        boolean expResult = false;
        boolean result = instance.isInstructor();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
}
