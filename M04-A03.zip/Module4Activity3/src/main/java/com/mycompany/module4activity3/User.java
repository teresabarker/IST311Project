/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.module4activity3;

import java.util.ArrayList;
import java.util.Calendar;
/**
 *
 * @author angel
 */
public class User extends UserRole {
    /**
     * @return the userFirstName
     */
    public String getUserFirstName() {
        return userFirstName;
    }

    /**
     * @param userFirstName the userFirstName to set
     */
    public void setUserFirstName(String userFirstName) {
        this.userFirstName = userFirstName;
    }

    /**
     * @return the userLastName
     */
    public String getUserLastName() {
        return userLastName;
    }

    /**
     * @param userLastName the userLastName to set
     */
    public void setUserLastName(String userLastName) {
        this.userLastName = userLastName;
    }

    /**
     * @return the userEmail
     */
    public String getUserEmail() {
        return userEmail;
    }

    /**
     * @param userEmail the userEmail to set
     */
    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    /**
     * @return the userPassword
     */
    public String getUserPassword() {
        return userPassword;
    }

    /**
     * @param userPassword the userPassword to set
     */
    public void setUserPassword(String userPassword) {
        this.userPassword = userPassword;
    }
    private String userFirstName;
    private String userLastName;
    private String userEmail;
    private String userPassword;
    
    public User(){
        super();
        this.userFirstName = "";
        this.userLastName = "";
        this.userEmail = "";
        this.userPassword = "";
    }
    
    public User(String userFirstName,String userLastName, String userEmail,String userPassword){
        super();
        this.userFirstName = userFirstName;
        this.userLastName = userLastName;
        this.userEmail = userEmail;
        this.userPassword = userPassword;
    }
    
    public User(String userFirstName,String userLastName, String userEmail,String userPassword, int userType,ArrayList<Calendar> userSchedule,ArrayList<String> userClasses,ArrayList<String> userDegrees){
        super(userType, userSchedule, userClasses, userDegrees);
        this.userFirstName = userFirstName;
        this.userLastName = userLastName;
        this.userEmail = userEmail;
        this.userPassword = userPassword;
    }
    
    public User(String userFirstName,String userLastName, String userEmail,String userPassword, int userType,Calendar userSchedule,String userClasses, String userDegrees){
        super(userType, userSchedule, userClasses, userDegrees);
        this.userFirstName = userFirstName;
        this.userLastName = userLastName;
        this.userEmail = userEmail;
        this.userPassword = userPassword;
    }
    
    public String getFullName(){
    return userFirstName + " " + userLastName;
    }
    
    public boolean isPassword(String password){
    return getUserPassword().equals(password);
    }
    
    public boolean isEmail(String user){
        return getUserEmail().equals(user);
    }
}
