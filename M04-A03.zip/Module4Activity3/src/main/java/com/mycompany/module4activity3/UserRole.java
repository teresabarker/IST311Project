/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.module4activity3;

import java.util.ArrayList;
import java.util.Calendar;

/**
 *
 * @author angel
 */
public class UserRole {

    /**
     * @return the userClasses
     */
    public ArrayList<String> getUserClasses() {
        return userClasses;
    }

    /**
     * @param userClasses the userClasses to set
     */
    public void setUserClasses(ArrayList<String> userClasses) {
        this.userClasses = userClasses;
    }

    /**
     * @return the userSchedule
     */
    public ArrayList<Calendar> getUserSchedule() {
        return userSchedule;
    }

    /**
     * @param userSchedule the userSchedule to set
     */
    public void setUserSchedule(ArrayList<Calendar> userSchedule) {
        this.userSchedule = userSchedule;
    }

    

    /**
     * @return the userType
     */
    public int getUserType() {
        return userType;
    }

    /**
     * @param userType the userType to set
     */
    public void setUserType(int userType) {
        this.userType = userType;
    }

    /**
     * @return the userDegrees
     */
    public ArrayList<String> getUserDegrees() {
        return userDegrees;
    }

    /**
     * @param userDegrees the userDegrees to set
     */
    public void setUserDegrees(ArrayList<String> userDegrees) {
        this.userDegrees = userDegrees;
    }
    private int userType;
    private ArrayList<Calendar> userSchedule = new ArrayList<>();
    private ArrayList<String> userClasses = new ArrayList<>();
    private ArrayList<String> userDegrees =  new ArrayList<>();
    
    public UserRole(){
        userType = 0;
        userSchedule.add(Calendar.getInstance());
        userClasses.add("");
        userDegrees.add("");
    }
    
    public UserRole(int userType,ArrayList<Calendar> userSchedule, ArrayList
            <String> userClasses,ArrayList
            <String> userDegrees){
        this.userType = userType;
        this.userSchedule = userSchedule;
        this.userClasses = userClasses;
        this.userDegrees = userDegrees;
    }
    
    public UserRole(int userType,Calendar userSchedule,String userClasses,String userDegree){
        this.userType = userType;
        this.userSchedule.add(userSchedule);
        this.userClasses.add(userClasses);
        this.userDegrees.add(userDegree);
    }
    
    public boolean isAvailable(){
        return false;
        //TODO
    }
    
    public boolean isInstructor(){
        return userType != 0;
    }
}
